# GitHub Actions setup

Create `.github/workflows/android-apk.yml` in your GitHub repository and paste the following workflow. Upload exactly one VideoDownloaderPro project ZIP to the repository root. The workflow uses the same Java / Gradle / sdkmanager pattern as the working CleanBrowser workflow and does not call `android-actions/setup-android@v3`.

```yaml
name: Build VideoDownloaderPro APK

on:
  workflow_dispatch:
  push:
    branches: [main]

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Find project ZIP
        id: project
        shell: bash
        run: |
          mapfile -t zips < <(find . -maxdepth 1 -type f -iname '*.zip' -printf '%f\n' | sort)
          if [ "${#zips[@]}" -ne 1 ]; then
            echo "Expected exactly one project ZIP in repository root; found ${#zips[@]}."
            printf '%s\n' "${zips[@]}"
            exit 1
          fi
          echo "zip_file=${zips[0]}" >> "$GITHUB_OUTPUT"
          echo "Using ${zips[0]}"

      - name: Unpack project
        shell: bash
        run: |
          mkdir -p "$RUNNER_TEMP/android-project"
          unzip -q "${{ steps.project.outputs.zip_file }}" -d "$RUNNER_TEMP/android-project"
          SETTINGS_FILE=$(find "$RUNNER_TEMP/android-project" -type f \
            \( -name settings.gradle.kts -o -name settings.gradle \) -print -quit)
          if [ -z "$SETTINGS_FILE" ]; then
            echo "ERROR: Gradle settings file not found inside project ZIP."
            exit 1
          fi
          PROJECT_DIR="$(dirname "$SETTINGS_FILE")"
          echo "PROJECT_DIR=$PROJECT_DIR" >> "$GITHUB_ENV"
          echo "Project directory: $PROJECT_DIR"

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.10.2'

      - name: Accept Android licenses
        shell: bash
        run: |
          SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
          if [ ! -x "$SDKMANAGER" ]; then
            SDKMANAGER="$(command -v sdkmanager)"
          fi
          yes | "$SDKMANAGER" --licenses > /dev/null || true

      - name: Install Android SDK packages
        shell: bash
        run: |
          SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
          if [ ! -x "$SDKMANAGER" ]; then
            SDKMANAGER="$(command -v sdkmanager)"
          fi
          "$SDKMANAGER" --install \
            "platform-tools" \
            "platforms;android-35" \
            "build-tools;35.0.0"

      - name: Build debug APK
        working-directory: ${{ env.PROJECT_DIR }}
        shell: bash
        run: |
          free -h
          gradle assembleDebug \
            --no-daemon \
            --max-workers=2 \
            --stacktrace \
            --console=plain

      - name: Verify APK
        run: test -s "${{ env.PROJECT_DIR }}/app/build/outputs/apk/debug/app-debug.apk"

      - uses: actions/upload-artifact@v4
        with:
          name: VideoDownloaderPro-debug-apk
          path: ${{ env.PROJECT_DIR }}/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
          retention-days: 30
```
