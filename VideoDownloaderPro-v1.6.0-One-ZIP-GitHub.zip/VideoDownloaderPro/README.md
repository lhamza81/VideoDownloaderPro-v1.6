# Video Downloader Pro — Android

Version 1.6.0. Android Studio source project with browser-based media discovery, pre-download HLS/DASH quality selection, and offline playback.

## Version 1.6.0 improvements
- Browser media discovery now combines HTML5 `<video>` / `<source>` elements, media links, the browser Performance resource list, and media URLs observed by WebView network requests.
- Recommended scan flow: open a page, start playback, wait briefly, then use **Find video**. This helps expose manifests requested only after playback begins.
- HLS/DASH manifests are inspected before download. Available video renditions are listed by resolution and, when known, bitrate.
- Choose **Auto / default quality** or one exact available resolution. The selected video rendition is requested with the default audio track.
- Direct MP4/WebM and other direct media links show a confirmation explaining that the original file is downloaded; separate quality options only exist when the source exposes them.
- Existing Media3 HLS/DASH offline queue, pause/resume/remove, cache storage, and offline playback remain included.

## Existing features retained
- Dark four-tab interface: Home, Browser, Downloads, Library.
- In-app WebView browser with navigation and page progress.
- Direct media-file downloads through Android DownloadManager, including WebView user-agent and cookies where available.
- Download status, progress, cancel/remove, Play/Share for completed files.
- Local video discovery and playback.
- Media3 ExoPlayer playback for common media, HLS and DASH.
- Offline stream progress, downloaded bytes, selected-quality label, cache usage, pause/resume, remove, and Play offline. Offline playback reuses the stored Media3 download request so the chosen rendition is played from cache.
- WebView cookies are forwarded to stream manifest/segment requests where Android exposes them.

## Downloading a video
1. Open a page in Browser.
2. Start the video and allow it to play briefly. Some sites request the media manifest only after playback begins.
3. Tap **Find video**.
4. Select the detected HLS/DASH manifest or direct media file.
5. For HLS/DASH, tap **Choose quality & download**, inspect the available resolutions, and select one before confirming.
6. For direct media files, confirm **Original quality**. A direct file URL generally exposes only one quality.
7. Manage transfers under Downloads. Completed offline streams can be played from there.

## HLS/DASH quality selection
- The app inspects the manifest with Media3 DownloadHelper and displays video resolutions actually advertised by that stream; it does not invent 360p/480p/720p/1080p/4K choices that are not present.
- Selecting a resolution applies a track override for that video rendition. The default audio track is retained.
- Auto / default quality uses Media3's default track selection.
- Estimated file size is not shown because many manifests do not provide a reliable total size before segment download.
- Some multi-period DASH presentations may change available renditions between periods; the app matches the chosen resolution in each period where available.

## Limitations and responsible use
- Supports accessible HTTPS, non-DRM streams only. It does not bypass DRM, paywalls, geo-restrictions, authentication requirements, or website rules.
- WebView cannot expose every streaming implementation. Blob URLs, encrypted media, streams hidden inside app-specific players, and some dynamically generated URLs may not be discoverable.
- Some sites require custom headers, expiring tokens, signed URLs, or session behavior beyond WebView cookies; those streams may fail.
- Live or dynamically changing playlists may not be suitable for offline download.
- Background transfers may be affected by Android battery/background policies.
- Offline stream data is stored in app-private storage. Clearing app data or uninstalling the app deletes it.

## App identity
- Application ID: `com.videodownloader.pro`
- Version: `1.6.0` (versionCode 6)
- Minimum Android: API 23 (Android 6.0)
- Target / compile SDK: API 35
- Media3: 1.4.1

## GitHub Actions — one ZIP upload
GitHub requires the workflow YAML to be committed outside the ZIP at `.github/workflows/android-apk.yml`; a workflow stored only inside a ZIP cannot start itself.

1. Upload this one project ZIP to the root of your GitHub repository.
2. Create `.github/workflows/android-apk.yml` in the repository and copy the workflow from this project's `.github/workflows/android-apk.yml` (or `GITHUB_WORKFLOW_SETUP.md`).
3. Commit both files. The workflow finds the single ZIP in the repository root, extracts the nested Gradle project, installs Android API 35, and builds the debug APK with Java 17 / Gradle 8.10.2.
4. Download `VideoDownloaderPro-debug-apk` from the successful Actions run.

Keep exactly one project ZIP in the repository root. The workflow follows the working CleanBrowser pattern and deliberately does not invoke `android-actions/setup-android@v3`.

## Build validation
This environment does not have the Android SDK / Gradle toolchain available, so the APK has not been compiled or device-tested here. The GitHub Actions workflow is included for the next build. If it fails, share the first failing step's complete log.
