package com.videodownloader.pro

import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.offline.DownloadHelper
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

@UnstableApi
class PlayerActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_OFFLINE_STREAM = "offline_stream"
        const val EXTRA_OFFLINE_DOWNLOAD_ID = "offline_download_id"
    }

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private var resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF101923.toInt()
        window.navigationBarColor = 0xFF101923.toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF101923.toInt())
        }
        playerView = PlayerView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            setBackgroundColor(0xFF101923.toInt())
            useController = true
            controllerShowTimeoutMs = 3500
            resizeMode = resizeMode
        }
        root.addView(playerView)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 12)
            setBackgroundColor(0xFF17232E.toInt())
        }
        controls.addView(controlButton("−10s") { seekBy(-10_000) })
        controls.addView(controlButton("+10s") { seekBy(10_000) })
        controls.addView(controlButton("Speed") { showSpeedOptions() })
        controls.addView(controlButton("Fit") { cycleResizeMode() })
        controls.addView(controlButton("Fullscreen") { toggleFullscreen() })
        root.addView(controls, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        val uri: Uri? = intent.data
        if (uri != null) {
            val cacheFactory = StreamDownloadStore.cacheDataSourceFactory(this)
            val downloadId = intent.getStringExtra(EXTRA_OFFLINE_DOWNLOAD_ID)
            val offlineRequest = if (intent.getBooleanExtra(EXTRA_OFFLINE_STREAM, false) && !downloadId.isNullOrBlank()) {
                try {
                    StreamDownloadStore.manager(this).currentDownloads
                        .firstOrNull { it.request.id == downloadId }?.request
                } catch (_: Exception) { null }
            } else null

            player = ExoPlayer.Builder(this)
                .setMediaSourceFactory(DefaultMediaSourceFactory(cacheFactory))
                .build().also { exo ->
                    playerView.player = exo
                    if (offlineRequest != null) {
                        // Use the stored DownloadRequest so Media3 exposes only the rendition
                        // selected before download, rather than probing uncached alternatives.
                        exo.setMediaSource(DownloadHelper.createMediaSource(offlineRequest, cacheFactory))
                    } else {
                        exo.setMediaItem(MediaItem.fromUri(uri))
                    }
                    exo.prepare()
                    exo.playWhenReady = true
                }
        } else finish()
    }

    private fun controlButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 11f
        setPadding(3, 4, 3, 4)
        setOnClickListener { action() }
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        p.seekTo((p.currentPosition + deltaMs).coerceAtLeast(0L))
    }

    private fun showSpeedOptions() {
        val speeds = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        val labels = speeds.map { if (it == 1.0f) "1.0× (Normal)" else "${it}×" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Playback speed")
            .setItems(labels) { _, which ->
                player?.playbackParameters = PlaybackParameters(speeds[which])
                Toast.makeText(this, "Speed: ${speeds[which]}×", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun cycleResizeMode() {
        resizeMode = when (resizeMode) {
            AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_FILL
            AspectRatioFrameLayout.RESIZE_MODE_FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        playerView.resizeMode = resizeMode
        val label = when (resizeMode) {
            AspectRatioFrameLayout.RESIZE_MODE_FILL -> "Fill"
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Zoom"
            else -> "Fit"
        }
        Toast.makeText(this, "Screen mode: $label", Toast.LENGTH_SHORT).show()
    }

    private fun toggleFullscreen() {
        val immersive = (window.decorView.systemUiVisibility and View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY) == 0
        window.decorView.systemUiVisibility = if (immersive) {
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        } else View.SYSTEM_UI_FLAG_VISIBLE
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
