package com.videodownloader.pro

import android.app.AlertDialog
import android.Manifest
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.content.pm.PackageManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.widget.*
import android.view.Gravity
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MimeTypes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.exoplayer.offline.DownloadHelper
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService as Media3DownloadService
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONTokener
import java.util.Locale
import java.io.IOException
import java.util.Collections
import kotlin.math.abs

@UnstableApi
class MainActivity : AppCompatActivity() {
    private val bg = 0xFF101923.toInt()
    private val panel = 0xFF1B2935.toInt()
    private val accent = 0xFF35B7A5.toInt()
    private lateinit var content: FrameLayout
    private lateinit var address: EditText
    private var web: WebView? = null
    private var currentTab = "Home"
    private val mediaPermissionRequest = 501
    private val notificationPermissionRequest = 502
    private var pendingOfflineRequest: DownloadRequest? = null
    private val detectedNetworkMedia = Collections.synchronizedSet(LinkedHashSet<String>())

    private data class VideoQualityOption(
        val width: Int,
        val height: Int,
        val bitrate: Int
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildShell()
        showHome()
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 18, 20, 14); setBackgroundColor(bg)
        }
        header.addView(TextView(this).apply {
            text = "▶  VIDEO DOWNLOADER"; textSize = 18f; setTextColor(-1)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply {
            text = "⋮"; textSize = 28f; setTextColor(-1)
            setOnClickListener { currentTab = "Settings"; showSettings() }
        })
        root.addView(header)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setBackgroundColor(0xFF17232E.toInt()); setPadding(4, 8, 4, 8)
        }
        listOf("Home", "Browser", "Downloads", "Library").forEach { tab ->
            nav.addView(TextView(this).apply {
                text = when (tab) { "Home" -> "⌂\nHome"; "Browser" -> "◎\nBrowser"; "Downloads" -> "↓\nDownloads"; else -> "▣\nLibrary" }
                gravity = Gravity.CENTER; textSize = 12f
                setTextColor(if (tab == currentTab) accent else 0xFFB8C5CE.toInt())
                setPadding(2, 4, 2, 4)
                setOnClickListener {
                    currentTab = tab
                    when (tab) {
                        "Home" -> showHome()
                        "Browser" -> showBrowser("https://www.google.com")
                        "Downloads" -> showDownloads()
                        else -> showLibrary()
                    }
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun page(title: String, subtitle: String? = null): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 12, 18, 18); setBackgroundColor(bg) }
        box.addView(TextView(this).apply {
            text = title; textSize = 24f; setTextColor(-1); typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        if (subtitle != null) box.addView(TextView(this).apply {
            text = subtitle; textSize = 13f; setTextColor(0xFF9EAFBC.toInt()); setPadding(0, 5, 0, 12)
        })
        return box
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16); setBackgroundColor(panel)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 10, 0, 10) }
    }

    private fun action(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(0xFF062B2A.toInt())
        backgroundTintList = android.content.res.ColorStateList.valueOf(accent)
        setOnClickListener { onClick() }
    }

    private fun smallAction(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(-1)
        setPadding(10, 10, 10, 10); setOnClickListener { onClick() }
    }

    private fun showHome() {
        web?.destroy(); web = null
        val p = page("Download videos", "Browse supported sites or paste a direct media link")
        val c = card()
        c.addView(TextView(this).apply { text = "Video URL"; setTextColor(-1); textSize = 15f })
        address = EditText(this).apply {
            hint = "https://example.com/video.mp4"; setHintTextColor(0xFF81919D.toInt())
            setTextColor(-1); setSingleLine(true); setPadding(12, 8, 12, 8)
            setBackgroundColor(0xFF263846.toInt()); inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        c.addView(address, LinearLayout.LayoutParams(-1, 52))
        c.addView(action("Download", ::downloadEnteredUrl), LinearLayout.LayoutParams(-1, -2))
        p.addView(c)
        val quick = card()
        quick.addView(TextView(this).apply {
            text = "Quick access"; textSize = 17f; typeface = android.graphics.Typeface.DEFAULT_BOLD; setTextColor(-1)
        })
        quick.addView(action("Open browser", { currentTab = "Browser"; showBrowser("https://www.google.com") }))
        quick.addView(action("My downloads", { currentTab = "Downloads"; showDownloads() }))
        quick.addView(action("Play local videos", { currentTab = "Library"; showLibrary() }))
        p.addView(quick)
        p.addView(TextView(this).apply {
            text = "Tip: start the video, wait a few seconds, then tap Find video. The scanner checks HTML5 video/source elements and media URLs observed by the browser. HLS/DASH downloads offer available quality choices before starting. DRM and website restrictions are not bypassed."
            textSize = 12f; setTextColor(0xFF9EAFBC.toInt()); setPadding(4, 12, 4, 4)
        })
        content.removeAllViews(); content.addView(ScrollView(this).apply { addView(p) })
    }

    private fun showBrowser(start: String) {
        web?.destroy()
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(8, 8, 8, 4) }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 0; visibility = android.view.View.GONE
        }
        shell.addView(progress, LinearLayout.LayoutParams(-1, 4))
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val url = EditText(this).apply {
            setSingleLine(true); textSize = 12f; hint = "Enter website address"; setText(start)
            setTextColor(-1); setHintTextColor(0xFF81919D.toInt()); setBackgroundColor(panel)
            setPadding(10, 4, 10, 4); inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        bar.addView(url, LinearLayout.LayoutParams(0, 48, 1f))
        bar.addView(smallAction("Go") { loadAddress(url.text.toString()) })
        shell.addView(bar)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        controls.addView(smallAction("‹") { web?.goBack() })
        controls.addView(smallAction("›") { web?.goForward() })
        controls.addView(smallAction("↻") { web?.reload() })
        controls.addView(smallAction("Find video") { findPageVideos() })
        shell.addView(controls)

        val browser = WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true; settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView, pageUrl: String, favicon: android.graphics.Bitmap?) {
                    detectedNetworkMedia.clear()
                    progress.visibility = android.view.View.VISIBLE
                    progress.progress = 5
                }
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val requestedUrl = request?.url?.toString()
                    if (!requestedUrl.isNullOrBlank() && isLikelyMediaUrl(requestedUrl)) {
                        detectedNetworkMedia.add(requestedUrl)
                    }
                    return super.shouldInterceptRequest(view, request)
                }
                override fun onPageFinished(view: WebView, pageUrl: String) {
                    if (!url.hasFocus()) url.setText(pageUrl)
                    progress.progress = 100
                    progress.postDelayed({ progress.visibility = android.view.View.GONE }, 250)
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progress.progress = newProgress
                    if (newProgress >= 100) progress.visibility = android.view.View.GONE
                    else progress.visibility = android.view.View.VISIBLE
                }
            }
            setDownloadListener { link, agent, disposition, mime, _ ->
                confirmDirectDownload(
                    link,
                    URLUtil.guessFileName(link, disposition, mime),
                    mime ?: "application/octet-stream",
                    agent
                )
            }
        }
        CookieManager.getInstance().setAcceptCookie(true)
        shell.addView(browser, LinearLayout.LayoutParams(-1, 0, 1f))
        web = browser
        content.removeAllViews(); content.addView(shell)
        browser.loadUrl(start)
    }

    private fun loadAddress(raw: String) {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return
        val value = if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) trimmed else "https://$trimmed"
        val uri = Uri.parse(value)
        if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) {
            Toast.makeText(this, "Enter a valid website address", Toast.LENGTH_SHORT).show(); return
        }
        web?.loadUrl(value)
    }

    // Scans the page DOM and browser-observed media requests. It does not inspect protected
    // app internals, decrypt DRM, or attempt to bypass site access controls.
    private fun findPageVideos() {
        val script = """
            (function(){
              const found=[];
              const add=(raw,force)=>{
                try {
                  const u=new URL(raw,document.baseURI);
                  if(u.protocol!=='https:'&&u.protocol!=='http:') return;
                  const path=(u.pathname||'').toLowerCase();
                  const media=/\.(m3u8|mpd|mp4|m4v|webm|mov|ogv|3gp|mkv|avi|flv|wmv|mpeg|mpg)(?:$)/i.test(path);
                  if((force||media)&&!found.includes(u.href)) found.push(u.href);
                } catch(e) {}
              };
              document.querySelectorAll('video').forEach(v=>{
                add(v.currentSrc,true); add(v.src,true);
                v.querySelectorAll('source').forEach(s=>add(s.src,true));
              });
              document.querySelectorAll('source').forEach(s=>add(s.src,true));
              document.querySelectorAll('a[href],link[rel="preload"][as="video"]').forEach(e=>add(e.href,false));
              try { performance.getEntriesByType('resource').forEach(e=>add(e.name,false)); } catch(e) {}
              return JSON.stringify(found.slice(0,40));
            })();
        """.trimIndent()
        web?.evaluateJavascript(script) { raw ->
            try {
                val decoded = JSONTokener(raw).nextValue() as? String ?: "[]"
                val values = JSONArray(decoded)
                val pageLinks = (0 until values.length()).map { values.optString(it) }
                    .filter { it.startsWith("http://") || it.startsWith("https://") }
                val observed = synchronized(detectedNetworkMedia) { detectedNetworkMedia.toList() }
                val links = (pageLinks + observed).distinct().take(40)
                if (links.isEmpty()) {
                    Toast.makeText(this, "No media URL found. Start playback, wait a moment, then scan again.", Toast.LENGTH_LONG).show()
                } else {
                    AlertDialog.Builder(this).setTitle("Detected media (${links.size})")
                        .setItems(links.map { mediaDisplayName(it) }.toTypedArray()) { _, which -> handleDetectedMedia(links[which]) }
                        .setNegativeButton("Close", null).show()
                }
            } catch (_: Exception) {
                Toast.makeText(this, "Could not read media links", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun isAdaptiveStreamUrl(link: String): Boolean {
        val path = Uri.parse(link).path?.lowercase(Locale.ROOT).orEmpty()
        return path.endsWith(".m3u8") || path.endsWith(".mpd")
    }

    private fun isLikelyMediaUrl(link: String): Boolean {
        val path = Uri.parse(link).path?.lowercase(Locale.ROOT).orEmpty()
        return listOf(".m3u8", ".mpd", ".mp4", ".m4v", ".webm", ".mov", ".ogv", ".3gp", ".mkv", ".avi", ".flv", ".wmv", ".mpeg", ".mpg").any { path.endsWith(it) }
    }

    private fun mediaDisplayName(link: String): String {
        val uri = Uri.parse(link)
        val name = uri.lastPathSegment?.takeIf { it.isNotBlank() } ?: uri.host.orEmpty()
        val type = when {
            isAdaptiveStreamUrl(link) && uri.path.orEmpty().endsWith(".m3u8", true) -> "HLS"
            isAdaptiveStreamUrl(link) -> "DASH"
            else -> "FILE"
        }
        return "$type  •  $name"
    }

    private fun handleDetectedMedia(link: String) {
        if (isAdaptiveStreamUrl(link)) {
            val kind = if (Uri.parse(link).path.orEmpty().endsWith(".m3u8", true)) "HLS" else "DASH"
            AlertDialog.Builder(this).setTitle("$kind stream detected")
                .setMessage("Inspect available video renditions, choose a quality, then download for offline viewing. Only accessible, non-DRM streams are supported.")
                .setPositiveButton("Choose quality & download") { _, _ -> startOfflineStream(link, kind) }
                .setNeutralButton("Play online") { _, _ -> startActivity(Intent(this, PlayerActivity::class.java).setData(Uri.parse(link))) }
                .setNegativeButton("Cancel", null).show()
        } else {
            confirmDirectDownload(link, URLUtil.guessFileName(link, null, null), "application/octet-stream", null)
        }
    }

    private fun downloadEnteredUrl() {
        val raw = address.text.toString().trim()
        if (raw.isBlank()) { address.error = "Enter a video URL"; return }
        val uri = Uri.parse(raw)
        if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) {
            address.error = "Enter a valid http(s) URL"; return
        }
        if (isAdaptiveStreamUrl(raw)) {
            val kind = if (uri.path.orEmpty().endsWith(".m3u8", true)) "HLS" else "DASH"
            AlertDialog.Builder(this).setTitle("$kind stream detected")
                .setMessage("Inspect available qualities before downloading this stream offline?")
                .setPositiveButton("Choose quality") { _, _ -> startOfflineStream(raw, kind) }
                .setNeutralButton("Play online") { _, _ -> startActivity(Intent(this, PlayerActivity::class.java).setData(uri)) }
                .setNegativeButton("Cancel", null).show()
        } else {
            confirmDirectDownload(raw, URLUtil.guessFileName(raw, null, null), "application/octet-stream", null)
        }
    }

    private fun confirmDirectDownload(url: String, name: String, mime: String, userAgent: String?) {
        val host = Uri.parse(url).host ?: "Direct media link"
        AlertDialog.Builder(this)
            .setTitle("Download original quality?")
            .setMessage("$name\n\nSource: $host\nQuality: Original file. This link exposes one file, so alternate resolutions are not available here.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Download") { _, _ -> enqueueDownload(url, name, mime, userAgent) }
            .show()
    }

    private fun startOfflineStream(url: String, kind: String) {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" || uri.host.isNullOrBlank()) {
            Toast.makeText(this, "For secure offline stream downloads, use an HTTPS URL", Toast.LENGTH_LONG).show()
            return
        }
        val mime = if (kind == "HLS") MimeTypes.APPLICATION_M3U8 else MimeTypes.APPLICATION_MPD
        val mediaItem = MediaItem.Builder().setUri(uri).setMimeType(mime).build()
        val downloadHelper = try {
            DownloadHelper.forMediaItem(
                this,
                mediaItem,
                StreamDownloadStore.httpFactory()
            )
        } catch (e: Exception) {
            showAutomaticStreamFallback(uri, kind, "Could not initialize stream inspection: ${e.message}")
            return
        }

        val spinner = ProgressBar(this).apply { isIndeterminate = true }
        var inspectionCancelled = false
        val preparingDialog = AlertDialog.Builder(this)
            .setTitle("Inspecting $kind stream")
            .setMessage("Reading available video qualities…")
            .setView(spinner)
            .setNegativeButton("Cancel") { _, _ ->
                inspectionCancelled = true
                downloadHelper.release()
            }
            .create()
        preparingDialog.setOnCancelListener {
            inspectionCancelled = true
            downloadHelper.release()
        }
        preparingDialog.show()

        try {
            downloadHelper.prepare(object : DownloadHelper.Callback {
                override fun onPrepared(helper: DownloadHelper, tracksInfoAvailable: Boolean) {
                    runOnUiThread {
                        if (inspectionCancelled || isFinishing || isDestroyed) {
                            preparingDialog.dismiss()
                            helper.release()
                            return@runOnUiThread
                        }
                        preparingDialog.dismiss()
                        val qualities = if (tracksInfoAvailable) collectVideoQualities(helper) else emptyList()
                        showQualityPicker(helper, kind, qualities)
                    }
                }

                override fun onPrepareError(helper: DownloadHelper, e: IOException) {
                    runOnUiThread {
                        preparingDialog.dismiss()
                        helper.release()
                        if (!inspectionCancelled && !isFinishing && !isDestroyed) {
                            showAutomaticStreamFallback(uri, kind, "Could not inspect available qualities: ${e.message}")
                        }
                    }
                }
            })
        } catch (e: Exception) {
            preparingDialog.dismiss()
            downloadHelper.release()
            showAutomaticStreamFallback(uri, kind, "Stream inspection failed: ${e.message}")
        }
    }

    private fun collectVideoQualities(helper: DownloadHelper): List<VideoQualityOption> {
        val bestBySize = LinkedHashMap<Pair<Int, Int>, VideoQualityOption>()
        for (periodIndex in 0 until helper.periodCount) {
            val groups = helper.getTrackGroups(periodIndex)
            for (groupIndex in 0 until groups.length) {
                val group = groups.get(groupIndex)
                if (group.type != C.TRACK_TYPE_VIDEO) continue
                for (trackIndex in 0 until group.length) {
                    val format = group.getFormat(trackIndex)
                    if (format.width <= 0 || format.height <= 0) continue
                    val option = VideoQualityOption(format.width, format.height, format.bitrate)
                    val key = format.width to format.height
                    val previous = bestBySize[key]
                    if (previous == null || option.bitrate > previous.bitrate) bestBySize[key] = option
                }
            }
        }
        return bestBySize.values.sortedWith(
            compareByDescending<VideoQualityOption> { it.height }
                .thenByDescending { it.width }
                .thenByDescending { it.bitrate }
        )
    }

    private fun showQualityPicker(helper: DownloadHelper, kind: String, qualities: List<VideoQualityOption>) {
        val labels = ArrayList<String>()
        labels.add("Auto / default quality")
        qualities.forEach { option ->
            val rate = if (option.bitrate > 0) "  •  ${String.format(Locale.US, "%.1f", option.bitrate / 1_000_000.0)} Mbps" else ""
            labels.add("${option.height}p  •  ${option.width}×${option.height}$rate")
        }
        val qualitySpinner = Spinner(this)
        qualitySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 4)
        }
        body.addView(TextView(this).apply {
            text = if (qualities.isEmpty()) "The stream did not expose separate video renditions. The default stream selection will be used." else "Select one video quality. Only the selected video rendition and the default audio track will be downloaded."
            textSize = 13f; setTextColor(0xFF40515E.toInt()); setPadding(0, 0, 0, 10)
        })
        body.addView(qualitySpinner)
        val dialog = AlertDialog.Builder(this)
            .setTitle("$kind download quality")
            .setView(body)
            .setNegativeButton("Cancel") { _, _ -> helper.release() }
            .setPositiveButton("Download") { _, _ ->
                try {
                    val selected = qualities.getOrNull(qualitySpinner.selectedItemPosition - 1)
                    val request = createSelectedDownloadRequest(helper, selected)
                    helper.release()
                    queueOfflineRequest(request, kind)
                } catch (e: Exception) {
                    helper.release()
                    Toast.makeText(this, "Could not create download: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .create()
        dialog.setOnCancelListener { helper.release() }
        dialog.show()
    }

    private fun createSelectedDownloadRequest(
        helper: DownloadHelper,
        selectedQuality: VideoQualityOption?
    ): DownloadRequest {
        for (periodIndex in 0 until helper.periodCount) {
            helper.clearTrackSelections(periodIndex)
            val parameters = DownloadHelper.getDefaultTrackSelectorParameters(this).buildUpon()
            if (selectedQuality != null) {
                val groups = helper.getTrackGroups(periodIndex)
                var bestGroup: TrackGroup? = null
                var bestTrackIndex = -1
                var bestDifference = Long.MAX_VALUE
                for (groupIndex in 0 until groups.length) {
                    val group = groups.get(groupIndex)
                    if (group.type != C.TRACK_TYPE_VIDEO) continue
                    for (trackIndex in 0 until group.length) {
                        val format = group.getFormat(trackIndex)
                        if (format.width != selectedQuality.width || format.height != selectedQuality.height) continue
                        val difference = if (selectedQuality.bitrate > 0 && format.bitrate > 0) {
                            abs(format.bitrate.toLong() - selectedQuality.bitrate.toLong())
                        } else 0L
                        if (difference < bestDifference) {
                            bestDifference = difference
                            bestGroup = group
                            bestTrackIndex = trackIndex
                        }
                    }
                }
                if (bestGroup != null && bestTrackIndex >= 0) {
                    parameters.addOverride(TrackSelectionOverride(bestGroup, bestTrackIndex))
                }
            }
            helper.addTrackSelection(periodIndex, parameters.build())
        }
        val id = "stream_${System.currentTimeMillis()}"
        val qualityTag = selectedQuality?.let { "${it.height}p" } ?: "Auto"
        return helper.getDownloadRequest(id, qualityTag.toByteArray(Charsets.UTF_8))
    }

    private fun showAutomaticStreamFallback(uri: Uri, kind: String, reason: String) {
        AlertDialog.Builder(this)
            .setTitle("Quality inspection unavailable")
            .setMessage("$reason\n\nYou can try queuing the stream with its default rendition selection. This does not bypass DRM or access restrictions.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Try automatic download") { _, _ ->
                val mime = if (kind == "HLS") MimeTypes.APPLICATION_M3U8 else MimeTypes.APPLICATION_MPD
                val request = DownloadRequest.Builder("stream_${System.currentTimeMillis()}", uri)
                    .setMimeType(mime)
                    .build()
                queueOfflineRequest(request, kind)
            }
            .show()
    }

    private fun queueOfflineRequest(request: DownloadRequest, kind: String) {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            pendingOfflineRequest = request
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationPermissionRequest)
            return
        }
        enqueueOfflineRequest(request, kind)
    }

    private fun enqueueOfflineRequest(request: DownloadRequest, kind: String) {
        try {
            Media3DownloadService.sendAddDownload(
                this,
                StreamDownloadService::class.java,
                request,
                true
            )
            Toast.makeText(this, "$kind ${request.id} queued for offline download", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not queue offline download: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun enqueueDownload(url: String, suggestedName: String, mime: String, userAgent: String?) {
        try {
            val parsed = Uri.parse(url)
            if (parsed.scheme !in listOf("http", "https") || parsed.host.isNullOrBlank()) {
                Toast.makeText(this, "Only HTTP and HTTPS links are supported", Toast.LENGTH_SHORT).show(); return
            }
            val safeName = suggestedName.substringAfterLast('/').substringAfterLast('\\')
                .replace(Regex("[\\\\/:*?\"<>|]"), "_").take(120)
                .ifBlank { "video_${System.currentTimeMillis()}" }
            val request = DownloadManager.Request(parsed).apply {
                setTitle(safeName); setDescription("Video Downloader Pro")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "VideoDownloaderPro/$safeName")
                setAllowedOverMetered(true); setAllowedOverRoaming(false)
                if (!userAgent.isNullOrBlank()) addRequestHeader("User-Agent", userAgent)
                CookieManager.getInstance().getCookie(url)?.takeIf { it.isNotBlank() }?.let { addRequestHeader("Cookie", it) }
                if (mime.isNotBlank()) setMimeType(mime)
            }
            val id = (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            getSharedPreferences("downloads", MODE_PRIVATE).edit().putString(id.toString(), safeName).apply()
            Toast.makeText(this, "Download started: $safeName", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start download: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private var downloadFilter = "All"

    private fun showDownloads() {
        val p = page("Downloads", "Manage transfers saved by Android Download Manager")
        val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor = manager.query(DownloadManager.Query())
        val records = ArrayList<DownloadRow>()
        if (cursor != null) cursor.use { cur ->
            val idCol = cur.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
            val titleCol = cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)
            val statusCol = cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
            val totalCol = cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val doneCol = cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            val reasonCol = cur.getColumnIndex(DownloadManager.COLUMN_REASON)
            val mimeCol = cur.getColumnIndex(DownloadManager.COLUMN_MEDIA_TYPE)
            while (cur.moveToNext()) {
                records.add(
                    DownloadRow(
                        id = cur.getLong(idCol),
                        title = cur.getString(titleCol) ?: "Download",
                        status = cur.getInt(statusCol),
                        total = cur.getLong(totalCol),
                        done = cur.getLong(doneCol),
                        reason = if (reasonCol >= 0) cur.getInt(reasonCol) else 0,
                        mime = if (mimeCol >= 0) cur.getString(mimeCol) else null
                    )
                )
            }
        }
        val completed = records.count { it.status == DownloadManager.STATUS_SUCCESSFUL }
        val active = records.count { it.status == DownloadManager.STATUS_RUNNING || it.status == DownloadManager.STATUS_PENDING }
        val failed = records.count { it.status == DownloadManager.STATUS_FAILED }
        val summary = card()
        summary.addView(TextView(this).apply {
            text = "${records.size} total  •  $active active  •  $completed completed  •  $failed failed"
            setTextColor(-1); textSize = 14f
        })
        summary.addView(action("Refresh downloads") { showDownloads() })
        if (completed > 0) summary.addView(smallAction("Clear completed downloads") {
            AlertDialog.Builder(this)
                .setTitle("Clear completed downloads?")
                .setMessage("This removes completed entries from the download list and deletes their downloaded files.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear") { _, _ ->
                    records.filter { it.status == DownloadManager.STATUS_SUCCESSFUL }.forEach { manager.remove(it.id) }
                    showDownloads()
                }.show()
        })
        p.addView(summary)

        val filters = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 4)
        }
        listOf("All", "Active", "Completed", "Failed").forEach { filter ->
            filters.addView(smallAction(if (downloadFilter == filter) "● $filter" else filter) {
                downloadFilter = filter
                showDownloads()
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        p.addView(filters)

        val visible = records.filter { row ->
            when (downloadFilter) {
                "Active" -> row.status == DownloadManager.STATUS_RUNNING || row.status == DownloadManager.STATUS_PENDING || row.status == DownloadManager.STATUS_PAUSED
                "Completed" -> row.status == DownloadManager.STATUS_SUCCESSFUL
                "Failed" -> row.status == DownloadManager.STATUS_FAILED
                else -> true
            }
        }
        if (visible.isEmpty()) p.addView(emptyLabel(if (records.isEmpty()) "No downloads yet. Start a download from Home or Browser." else "No $downloadFilter downloads."))
        visible.forEach { row ->
            val state = when (row.status) {
                DownloadManager.STATUS_SUCCESSFUL -> "Completed"
                DownloadManager.STATUS_FAILED -> "Failed (code ${row.reason})"
                DownloadManager.STATUS_PAUSED -> "Paused"
                DownloadManager.STATUS_PENDING -> "Waiting"
                DownloadManager.STATUS_RUNNING -> "Downloading"
                else -> "Unknown"
            }
            val percent = if (row.total > 0) (row.done * 100 / row.total).toInt().coerceIn(0, 100) else 0
            val c = card()
            c.addView(TextView(this).apply {
                text = row.title; textSize = 15f; setTextColor(-1); maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            c.addView(TextView(this).apply {
                text = if (row.total > 0) "$state  •  $percent%  •  ${formatBytes(row.done)} / ${formatBytes(row.total)}" else "$state  •  ${formatBytes(row.done)}"
                setTextColor(0xFFB8C5CE.toInt()); textSize = 12f
            })
            if (row.status == DownloadManager.STATUS_RUNNING || row.status == DownloadManager.STATUS_PENDING) {
                c.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 100; progress = percent
                }, LinearLayout.LayoutParams(-1, 8))
            }
            val rowActions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            if (row.status == DownloadManager.STATUS_SUCCESSFUL) {
                val fileUri = manager.getUriForDownloadedFile(row.id)
                if (fileUri != null) {
                    c.addView(thumbnailView(fileUri), LinearLayout.LayoutParams(132, 78))
                    rowActions.addView(smallAction("Play") {
                        startActivity(Intent(this@MainActivity, PlayerActivity::class.java).setData(fileUri))
                    })
                    rowActions.addView(smallAction("Share") {
                        val share = Intent(Intent.ACTION_SEND).apply {
                            type = row.mime ?: "video/*"
                            putExtra(Intent.EXTRA_STREAM, fileUri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(share, "Share video"))
                    })
                }
            }
            rowActions.addView(smallAction(if (row.status == DownloadManager.STATUS_RUNNING || row.status == DownloadManager.STATUS_PENDING) "Cancel" else "Remove") {
                val dialog = AlertDialog.Builder(this)
                    .setTitle(if (row.status == DownloadManager.STATUS_RUNNING || row.status == DownloadManager.STATUS_PENDING) "Cancel download?" else "Remove download?")
                    .setMessage(row.title)
                    .setNegativeButton("Keep", null)
                    .setPositiveButton(if (row.status == DownloadManager.STATUS_RUNNING || row.status == DownloadManager.STATUS_PENDING) "Cancel" else "Remove") { _, _ ->
                        manager.remove(row.id)
                        showDownloads()
                    }
                dialog.show()
            })
            c.addView(rowActions)
            p.addView(c)
        }
        addOfflineStreamsSection(p)
        content.removeAllViews()
        content.addView(ScrollView(this).apply { addView(p) })
    }

    private fun addOfflineStreamsSection(parent: LinearLayout) {
        val section = card()
        section.addView(TextView(this).apply {
            text = "HLS / DASH offline downloads"
            textSize = 17f; setTextColor(-1)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        section.addView(TextView(this).apply {
            text = "Segmented streams are stored in app-private storage. Wait for Completed before using Play offline."
            textSize = 12f; setTextColor(0xFFB8C5CE.toInt())
        })
        val cacheBytes = try { StreamDownloadStore.cache(this).cacheSpace } catch (_: Exception) { 0L }
        section.addView(TextView(this).apply {
            text = "Offline cache used: ${formatBytes(cacheBytes)}"
            textSize = 12f; setTextColor(0xFF9EAFBC.toInt())
        })
        val downloads = try { StreamDownloadStore.manager(this).currentDownloads } catch (_: Exception) { emptyList() }
        if (downloads.isEmpty()) {
            section.addView(emptyLabel("No HLS/DASH offline downloads yet. Open a direct .m3u8 or .mpd link, or use Find video in the browser."))
        }
        downloads.sortedByDescending { it.startTimeMs }.forEach { download ->
            val state = when (download.state) {
                Download.STATE_QUEUED -> "Queued"
                Download.STATE_DOWNLOADING -> "Downloading"
                Download.STATE_COMPLETED -> "Completed"
                Download.STATE_FAILED -> "Failed"
                Download.STATE_STOPPED -> "Paused"
                Download.STATE_REMOVING -> "Removing"
                Download.STATE_RESTARTING -> "Restarting"
                else -> "Preparing"
            }
            val percent = if (download.percentDownloaded.isNaN()) 0 else download.percentDownloaded.toInt().coerceIn(0, 100)
            val item = card()
            val displayName = download.request.uri.lastPathSegment?.substringBefore('?')?.takeIf { it.isNotBlank() } ?: download.request.id
            item.addView(TextView(this).apply {
                text = displayName
                textSize = 13f; setTextColor(-1); maxLines = 1
            })
            item.addView(TextView(this).apply {
                val sizeText = if (download.contentLength > 0) "${formatBytes(download.bytesDownloaded)} / ${formatBytes(download.contentLength)}" else formatBytes(download.bytesDownloaded)
                val failureText = if (download.state == Download.STATE_FAILED) " • Error ${download.failureReason}" else ""
                val qualityTag = download.request.data?.let { String(it, Charsets.UTF_8) }.orEmpty()
                val qualityText = if (qualityTag.isNotBlank()) " • $qualityTag" else ""
                text = "$state • $percent% • $sizeText$qualityText$failureText"
                textSize = 12f; setTextColor(0xFFB8C5CE.toInt())
            })
            if (download.state == Download.STATE_DOWNLOADING || download.state == Download.STATE_QUEUED) {
                item.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 100; progress = percent
                }, LinearLayout.LayoutParams(-1, 8))
            }
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            when (download.state) {
                Download.STATE_DOWNLOADING, Download.STATE_QUEUED -> actions.addView(smallAction("Pause") {
                    Media3DownloadService.sendSetStopReason(this@MainActivity, StreamDownloadService::class.java, download.request.id, 1, true)
                    showDownloads()
                })
                Download.STATE_STOPPED -> actions.addView(smallAction("Resume") {
                    Media3DownloadService.sendSetStopReason(this@MainActivity, StreamDownloadService::class.java, download.request.id, Download.STOP_REASON_NONE, true)
                    showDownloads()
                })
                Download.STATE_COMPLETED -> actions.addView(smallAction("Play offline") {
                    startActivity(Intent(this@MainActivity, PlayerActivity::class.java)
                        .setData(download.request.uri)
                        .putExtra(PlayerActivity.EXTRA_OFFLINE_STREAM, true)
                        .putExtra(PlayerActivity.EXTRA_OFFLINE_DOWNLOAD_ID, download.request.id))
                })
            }
            actions.addView(smallAction("Remove") {
                AlertDialog.Builder(this@MainActivity).setTitle("Remove offline stream?")
                    .setMessage("This deletes the cached stream data for this download.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Remove") { _, _ ->
                        Media3DownloadService.sendRemoveDownload(this@MainActivity, StreamDownloadService::class.java, download.request.id, false)
                        showDownloads()
                    }.show()
            })
            item.addView(actions)
            section.addView(item)
        }
        section.addView(action("Refresh offline downloads") { showDownloads() })
        parent.addView(section)
    }

    private data class DownloadRow(
        val id: Long,
        val title: String,
        val status: Int,
        val total: Long,
        val done: Long,
        val reason: Int,
        val mime: String?
    )

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb)
        return String.format(Locale.US, "%.2f GB", mb / 1024.0)
    }

    private fun showLibrary() {
        val permission = if (android.os.Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_VIDEO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            AlertDialog.Builder(this)
                .setTitle("Media library access")
                .setMessage("Allow access to videos on this device so Video Downloader Pro can display and play your local video files.")
                .setPositiveButton("Continue") { _, _ ->
                    ActivityCompat.requestPermissions(this, arrayOf(permission), mediaPermissionRequest)
                }
                .setNegativeButton("Not now", null)
                .show()
            return
        }
        val p = page("Video library", "Videos indexed on this device")
        val projection = arrayOf(android.provider.MediaStore.Video.Media._ID, android.provider.MediaStore.Video.Media.DISPLAY_NAME)
        val videos = ArrayList<Pair<String, Uri>>()
        contentResolver.query(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null,
            "${android.provider.MediaStore.Video.Media.DATE_ADDED} DESC")?.use { cur ->
            val idCol = cur.getColumnIndexOrThrow(android.provider.MediaStore.Video.Media._ID)
            val nameCol = cur.getColumnIndexOrThrow(android.provider.MediaStore.Video.Media.DISPLAY_NAME)
            while (cur.moveToNext()) {
                val id = cur.getLong(idCol); val name = cur.getString(nameCol) ?: "Video"
                videos.add(name to Uri.withAppendedPath(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString()))
            }
        }
        if (videos.isEmpty()) p.addView(emptyLabel("No local videos found. Downloaded videos may take a moment to appear after Android indexes them."))
        videos.forEach { (name, uri) ->
            val c = card()
            c.orientation = LinearLayout.HORIZONTAL
            c.gravity = Gravity.CENTER_VERTICAL
            c.addView(thumbnailView(uri), LinearLayout.LayoutParams(124, 78))
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 0, 0, 0) }
            details.addView(TextView(this).apply { text = name; textSize = 14f; setTextColor(-1); maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
            details.addView(smallAction("▶  Play") { startActivity(Intent(this@MainActivity, PlayerActivity::class.java).setData(uri)) })
            c.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            p.addView(c)
        }
        p.addView(action("Refresh library", ::showLibrary))
        content.removeAllViews(); content.addView(ScrollView(this).apply { addView(p) })
    }


    private fun thumbnailView(uri: Uri): ImageView {
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF263846.toInt())
            setImageResource(android.R.drawable.ic_media_play)
            contentDescription = "Video thumbnail"
        }
        Thread {
            val bitmap = try {
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    contentResolver.loadThumbnail(uri, android.util.Size(320, 180), null)
                } else {
                    val retriever = android.media.MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(this, uri)
                        retriever.getFrameAtTime(1_000_000, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    } finally { retriever.release() }
                }
            } catch (_: Exception) { null }
            if (bitmap != null && !isFinishing) runOnUiThread { image.setImageBitmap(bitmap) }
        }.start()
        return image
    }

    private fun showSettings() {
        val p = page("Settings", "Video Downloader Pro")
        p.addView(card().apply {
            addView(TextView(this@MainActivity).apply {
                text = "Downloads are saved in Downloads/VideoDownloaderPro. The browser scans HTML5 video/source elements and browser-observed media requests. HLS/DASH manifests are inspected before downloading so you can choose an available video resolution; the default audio track is retained. Direct files are downloaded in their original quality. Offline HLS/DASH is limited to accessible non-DRM streams."
                setTextColor(-1); textSize = 14f
            })
            addView(TextView(this@MainActivity).apply { text = "Version 1.6.0"; setTextColor(0xFF9EAFBC.toInt()); setPadding(0, 12, 0, 0) })
        })
        content.removeAllViews(); content.addView(p)
    }

    private fun emptyLabel(value: String) = TextView(this).apply {
        text = value; textSize = 14f; setTextColor(0xFF9EAFBC.toInt()); setPadding(8, 24, 8, 24)
    }

    @Deprecated("Deprecated in Android API")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == mediaPermissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            showLibrary()
        } else if (requestCode == mediaPermissionRequest) {
            Toast.makeText(this, "Video library permission was not granted", Toast.LENGTH_SHORT).show()
        } else if (requestCode == notificationPermissionRequest) {
            val pending = pendingOfflineRequest
            pendingOfflineRequest = null
            if (pending != null) enqueueOfflineRequest(pending, "HLS/DASH")
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (currentTab == "Browser" && web?.canGoBack() == true) web?.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        web?.stopLoading(); web?.destroy(); web = null
        super.onDestroy()
    }
}
